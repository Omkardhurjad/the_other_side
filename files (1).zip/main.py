"""
main.py — FastAPI entry point for The Other Side ADK Agent
============================================================
Wraps the ADK agent in a FastAPI app using get_fast_api_app(),
adds custom endpoints for health checks, multimodal file upload,
rate limiting hooks, and CORS for the Chrome extension.

Deploy with:
  uvicorn main:app --host 0.0.0.0 --port 8080
Or via Cloud Run:
  adk deploy cloud_run --project $PROJECT_ID --region $REGION
"""

import os
import base64
import mimetypes
import logging
from contextlib import asynccontextmanager
from typing import Optional

import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from google.adk.cli.fast_api import get_fast_api_app

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("the_other_side")

# ── Config from environment ───────────────────────────────────────────────────
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))

# Session persistence: use Cloud SQL (PostgreSQL) in production,
# SQLite for local dev. Set SESSION_SERVICE_URI env var.
SESSION_SERVICE_URI = os.getenv(
    "SESSION_SERVICE_URI",
    "sqlite+aiosqlite:///./sessions.db"  # local dev only
)

# CORS: lock down to your frontend domain(s) in production
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:3000,http://localhost:8080,chrome-extension://*"
).split(",")

# Max upload size: 10 MB
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", 10 * 1024 * 1024))

# ── Build ADK FastAPI app ─────────────────────────────────────────────────────
app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    session_service_uri=SESSION_SERVICE_URI,
    allow_origins=ALLOWED_ORIGINS,
    web=False,                     # no dev UI in production; set True for dev
    trace_to_cloud=os.getenv("TRACE_TO_CLOUD", "false").lower() == "true",
)

# ── CORS middleware (covers custom routes below) ──────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Pydantic models for custom endpoints ─────────────────────────────────────

class PerspectiveRequest(BaseModel):
    """Request body for the /flip endpoint."""
    situation_text: str          # plain-text description of the situation
    angle: str = "empathy"       # lens angle
    context: Optional[str] = None
    user_id: str = "anonymous"
    session_id: Optional[str] = None


class FlipResponse(BaseModel):
    original_description: str
    angle_label: str
    frames: list
    full_poem_text: str
    session_id: str


# ── Custom routes ─────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """Liveness probe for Cloud Run / load balancers."""
    return {"status": "ok", "service": "the-other-side-agent"}


@app.get("/angles")
async def get_angles():
    """Return all available lens angles — used by the frontend."""
    from the_other_side_agent.agent import ANGLES
    return {
        k: {
            "label": v["label"],
            "frame_labels": v["frame_labels"],
        }
        for k, v in ANGLES.items()
    }


@app.post("/upload-media")
async def upload_media(
    file: UploadFile = File(...),
    angle: str = Form("empathy"),
    context: str = Form(""),
    user_id: str = Form("anonymous"),
):
    """
    Accept a multimodal file (image / audio / video), base64-encode it,
    and return the data URI ready to be injected into an ADK /run call.

    The Chrome extension POSTs here first, then uses the returned
    media_data_uri in a subsequent /run call to the ADK agent.
    """
    content = await file.read()

    # Guard: size check
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Max {MAX_UPLOAD_BYTES // (1024*1024)} MB."
        )

    # Guard: MIME type allowlist
    mime = file.content_type or mimetypes.guess_type(file.filename or "")[0] or ""
    allowed_mimes = {
        "image/jpeg", "image/png", "image/webp", "image/gif",
        "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm",
        "video/mp4", "video/webm", "video/quicktime",
    }
    if mime not in allowed_mimes:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported media type: {mime}. Allowed: image, audio, video."
        )

    b64 = base64.b64encode(content).decode("utf-8")
    data_uri = f"data:{mime};base64,{b64}"

    logger.info(f"Media upload: mime={mime} size={len(content)} angle={angle}")

    return {
        "media_data_uri": data_uri,
        "mime_type": mime,
        "angle": angle,
        "context": context,
        "user_id": user_id,
        "size_bytes": len(content),
    }


@app.get("/")
async def root():
    return {
        "service": "The Other Side — Perspective Flipping Agent",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "angles": "/angles",
            "upload": "/upload-media",
            "adk_run": "/run",
            "adk_run_sse": "/run_sse",
            "docs": "/docs",
        },
    }


# ── Dev entrypoint ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8080)),
        reload=os.getenv("ENV", "production") == "development",
        log_level="info",
    )
