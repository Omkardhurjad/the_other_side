/**
 * popup.js — The Other Side Chrome Extension Popup
 * Handles UI interactions, communicates with background.js for API calls,
 * renders poem storyboard, and drives Web Speech narration.
 */

// ── Frame colour palettes ─────────────────────────────────────────────────────
const PALETTES = [
  { bg: "#160a2a", accent: "#c084fc", text: "#f3e8ff" },
  { bg: "#0a1827", accent: "#60a5fa", text: "#e0f2fe" },
  { bg: "#0d2010", accent: "#4ade80", text: "#dcfce7" },
  { bg: "#271408", accent: "#fb923c", text: "#fff7ed" },
  { bg: "#27081a", accent: "#f472b6", text: "#fce7f3" },
];

// ── State ─────────────────────────────────────────────────────────────────────
let selectedAngle = "empathy";
let currentFrameIndex = 0;
let framesData = [];
let mediaDataUrl = null;
let mediaType = null;
let isPlaying = false;
let userId = null;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const uploadZone   = document.getElementById("upload-zone");
const fileInput    = document.getElementById("file-input");
const contextInput = document.getElementById("context-input");
const flipBtn      = document.getElementById("flip-btn");
const statusEl     = document.getElementById("status");
const statusText   = document.getElementById("status-text");
const errorEl      = document.getElementById("error");
const resultEl     = document.getElementById("result");
const originalDesc = document.getElementById("original-desc");
const poemFrames   = document.getElementById("poem-frames");
const frameNav     = document.getElementById("frame-nav");
const playBtn      = document.getElementById("play-btn");
const resetBtn     = document.getElementById("reset-btn");

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  // Restore saved angle + userId
  const stored = await chrome.storage.local.get(["angle", "userId"]);
  if (stored.angle) setAngle(stored.angle);
  userId = stored.userId || ("user_" + Math.random().toString(36).slice(2, 10));
  await chrome.storage.local.set({ userId });

  // Check for pending flip (from context menu)
  const { pendingFlip } = await chrome.storage.local.get("pendingFlip");
  if (pendingFlip) {
    await chrome.storage.local.remove("pendingFlip");
    handlePendingFlip(pendingFlip);
  }
}

async function handlePendingFlip(flip) {
  if (flip.type === "image_url") {
    showStatus("Loading image…");
    try {
      const res = await fetch(flip.src);
      const blob = await res.blob();
      const reader = new FileReader();
      reader.onload = e => {
        mediaDataUrl = e.target.result;
        mediaType = blob.type;
        updateUploadZone(`Image loaded from page`);
        flipBtn.disabled = false;
        hideStatus();
      };
      reader.readAsDataURL(blob);
    } catch { showError("Could not load image from page."); }
  } else if (flip.type === "text") {
    contextInput.value = flip.context || "";
    flipBtn.disabled = false;
  }
}

// ── Angle buttons ─────────────────────────────────────────────────────────────
document.getElementById("angles").addEventListener("click", e => {
  const btn = e.target.closest(".angle-btn");
  if (!btn) return;
  setAngle(btn.dataset.angle);
});

function setAngle(angle) {
  selectedAngle = angle;
  document.querySelectorAll(".angle-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.angle === angle);
  });
  chrome.storage.local.set({ angle });
}

// ── Upload zone ───────────────────────────────────────────────────────────────
uploadZone.addEventListener("click", () => fileInput.click());
uploadZone.addEventListener("dragover", e => { e.preventDefault(); uploadZone.style.borderColor = "#f0c96a44"; });
uploadZone.addEventListener("dragleave", () => { uploadZone.style.borderColor = ""; });
uploadZone.addEventListener("drop", e => {
  e.preventDefault();
  uploadZone.style.borderColor = "";
  const file = e.dataTransfer.files[0];
  if (file) handleFileSelect(file);
});
fileInput.addEventListener("change", e => {
  if (e.target.files[0]) handleFileSelect(e.target.files[0]);
});

function handleFileSelect(file) {
  if (file.size > 10 * 1024 * 1024) {
    showError("File too large (max 10 MB).");
    return;
  }
  mediaType = file.type;
  const reader = new FileReader();
  reader.onload = e => {
    mediaDataUrl = e.target.result;
    updateUploadZone(`${file.name} (${(file.size / 1024).toFixed(0)} KB)`);
    flipBtn.disabled = false;
    clearError();
  };
  reader.readAsDataURL(file);
}

function updateUploadZone(text) {
  uploadZone.querySelector(".upload-zone-text").textContent = text;
  uploadZone.querySelector(".upload-zone-sub").textContent = "Click to change file";
  uploadZone.style.borderColor = "#f0c96a44";
}

// Enable flip if only context is provided (no media)
contextInput.addEventListener("input", () => {
  if (contextInput.value.trim()) flipBtn.disabled = false;
});

// ── Flip! ─────────────────────────────────────────────────────────────────────
flipBtn.addEventListener("click", async () => {
  const context = contextInput.value.trim();
  if (!mediaDataUrl && !context) return;

  flipBtn.disabled = true;
  resultEl.classList.remove("show");
  clearError();
  showStatus("Reading your side…");

  try {
    let agentResponse;

    if (mediaDataUrl) {
      // Upload media first, then run agent
      showStatus("Uploading media…");
      agentResponse = await sendMessage("UPLOAD_MEDIA", {
        dataUrl: mediaDataUrl,
        mimeType: mediaType,
        angle: selectedAngle,
        context,
        userId,
      });
    } else {
      // Text-only flip
      showStatus("Writing the other side…");
      agentResponse = await sendMessage("RUN_AGENT", {
        situationText: context,
        angle: selectedAngle,
        userId,
        sessionId: null,
      });
    }

    if (agentResponse.error) throw new Error(agentResponse.error);

    showStatus("Writing the poem…");
    const parsed = parseAgentResponse(agentResponse.result);
    if (!parsed) throw new Error("Could not parse agent response. Please try again.");

    hideStatus();
    renderResult(parsed);

  } catch (err) {
    hideStatus();
    showError(err.message || "Something went wrong. Please try again.");
    flipBtn.disabled = false;
  }
});

// ── Parse agent response ──────────────────────────────────────────────────────
function parseAgentResponse(result) {
  // ADK /run returns an array of events; find the last text content
  if (!result || !Array.isArray(result)) return null;

  let text = "";
  for (const event of result) {
    if (event?.content?.parts) {
      for (const part of event.content.parts) {
        if (part.text) text += part.text;
      }
    }
  }

  if (!text) return null;

  // Try to extract JSON from the text
  try {
    const match = text.match(/\{[\s\S]*"frames"[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
  } catch {}

  // Fallback: try parsing the whole text
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch {}

  return null;
}

// ── Render result ─────────────────────────────────────────────────────────────
function renderResult(data) {
  framesData = data.frames || [];
  currentFrameIndex = 0;

  originalDesc.textContent = data.original_description || "";

  // Build frame nav dots
  frameNav.innerHTML = framesData.map((_, i) => `
    <div class="nav-dot ${i === 0 ? "active" : ""}" data-i="${i}"
      style="${i === 0 ? `background:${PALETTES[0].accent};width:18px` : ""}"></div>
  `).join("");

  frameNav.addEventListener("click", e => {
    const dot = e.target.closest(".nav-dot");
    if (dot) showFrame(parseInt(dot.dataset.i));
  });

  renderFrame(0);
  resultEl.classList.add("show");
  playBtn.textContent = "▶ Play aloud";
}

function showFrame(i) {
  currentFrameIndex = i;
  renderFrame(i);
  document.querySelectorAll(".nav-dot").forEach((d, idx) => {
    const pal = PALETTES[idx % PALETTES.length];
    d.style.background = idx === i ? pal.accent : "#1a1a2c";
    d.style.width = idx === i ? "18px" : "6px";
  });
}

function renderFrame(i) {
  const f = framesData[i];
  if (!f) return;
  const pal = PALETTES[i % PALETTES.length];

  poemFrames.innerHTML = `
    <div class="poem-frame" style="background:${pal.bg}; border:1px solid ${pal.accent}44">
      <span class="scene-label" style="color:${pal.accent}">${f.sceneLabel} · ${i+1}/${framesData.length}</span>
      ${(f.lines || []).map((line, j) => `
        <div class="poem-line ${j % 2 === 1 ? "italic" : ""}"
          style="color:${j === 0 ? pal.text : pal.text + "bb"}; font-size:${j === 0 ? "15px" : "13px"}">
          ${line}
        </div>
      `).join("")}
      <div class="poem-emoji">${f.emoji || ""}</div>
    </div>
    <div style="display:flex;justify-content:space-between;margin-top:4px">
      <button onclick="prevFrame()" style="background:transparent;border:none;color:#52506a;cursor:pointer;font-size:18px">‹</button>
      <button onclick="nextFrame()" style="background:transparent;border:none;color:#52506a;cursor:pointer;font-size:18px">›</button>
    </div>
  `;
}

window.prevFrame = () => {
  if (currentFrameIndex > 0) showFrame(currentFrameIndex - 1);
};
window.nextFrame = () => {
  if (currentFrameIndex < framesData.length - 1) showFrame(currentFrameIndex + 1);
};

// ── Audio narration ───────────────────────────────────────────────────────────
playBtn.addEventListener("click", () => {
  if (isPlaying) {
    window.speechSynthesis.cancel();
    isPlaying = false;
    playBtn.textContent = "▶ Play aloud";
    return;
  }
  playPoemFromFrame(0);
});

function playPoemFromFrame(startIdx) {
  if (!framesData.length) return;
  isPlaying = true;
  playBtn.textContent = "⏸ Pause";
  let idx = startIdx;

  const next = () => {
    if (idx >= framesData.length || !isPlaying) {
      isPlaying = false;
      playBtn.textContent = "▶ Play aloud";
      return;
    }
    showFrame(idx);
    const text = framesData[idx].lines.join(" … ");
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.78; u.pitch = 1.05;
    const voices = window.speechSynthesis.getVoices();
    const v = voices.find(v => v.name.includes("Google UK English Female") || v.name.includes("Samantha"));
    if (v) u.voice = v;
    u.onend = () => { idx++; setTimeout(next, 600); };
    window.speechSynthesis.speak(u);
  };
  next();
}

// ── Reset ─────────────────────────────────────────────────────────────────────
resetBtn.addEventListener("click", () => {
  window.speechSynthesis.cancel();
  isPlaying = false;
  mediaDataUrl = null;
  mediaType = null;
  framesData = [];
  resultEl.classList.remove("show");
  clearError();
  hideStatus();
  flipBtn.disabled = true;
  contextInput.value = "";
  uploadZone.querySelector(".upload-zone-text").textContent = "Drop an image or click to upload";
  uploadZone.querySelector(".upload-zone-sub").textContent = 'Or use right-click → "The Other Side" on any image';
  uploadZone.style.borderColor = "";
  playBtn.textContent = "▶ Play aloud";
});

// ── UI helpers ────────────────────────────────────────────────────────────────
function showStatus(msg) {
  statusText.textContent = msg;
  statusEl.style.display = "block";
}
function hideStatus() { statusEl.style.display = "none"; }
function showError(msg) { errorEl.textContent = msg; errorEl.style.display = "block"; }
function clearError() { errorEl.style.display = "none"; }

function sendMessage(type, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, response => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

// ── Boot ──────────────────────────────────────────────────────────────────────
init();
