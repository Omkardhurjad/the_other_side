/**
 * background.js — The Other Side Chrome Extension
 * Service worker: handles context menu, coordinates API calls,
 * manages session IDs, and relays messages to popup.
 */

const API_BASE = "https://your-cloudrun-service-url.run.app"; // ← update after deploy
const APP_NAME = "the_other_side_agent";

// ── Context menu setup ────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "flip-image",
    title: "The Other Side: Flip this image",
    contexts: ["image"],
  });
  chrome.contextMenus.create({
    id: "flip-page",
    title: "The Other Side: Flip this page",
    contexts: ["page", "selection"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const stored = await chrome.storage.local.get(["angle", "userId"]);
  const angle = stored.angle || "empathy";
  const userId = stored.userId || generateUserId();

  if (info.menuItemId === "flip-image" && info.srcUrl) {
    // Send to popup to handle (popup must be open, or open it)
    chrome.storage.local.set({
      pendingFlip: {
        type: "image_url",
        src: info.srcUrl,
        angle,
        userId,
        pageUrl: tab.url,
        pageTitle: tab.title,
      },
    });
    chrome.action.openPopup();
  }

  if (info.menuItemId === "flip-page") {
    const context = info.selectionText
      ? `Selected text: "${info.selectionText}"`
      : `Page: ${tab.title} at ${tab.url}`;

    chrome.storage.local.set({
      pendingFlip: {
        type: "text",
        context,
        angle,
        userId,
        pageUrl: tab.url,
        pageTitle: tab.title,
      },
    });
    chrome.action.openPopup();
  }
});

// ── Message relay from popup ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "RUN_AGENT") {
    runAgent(msg.payload).then(sendResponse).catch(err =>
      sendResponse({ error: err.message })
    );
    return true; // keep channel open for async
  }

  if (msg.type === "UPLOAD_MEDIA") {
    // msg.payload: { dataUrl, mimeType, angle, context, userId }
    uploadAndRun(msg.payload).then(sendResponse).catch(err =>
      sendResponse({ error: err.message })
    );
    return true;
  }
});

// ── Core API functions ────────────────────────────────────────────────────────

async function runAgent({ situationText, angle, userId, sessionId }) {
  // 1. Create session if needed
  const sid = sessionId || generateSessionId();
  await createSession(userId, sid);

  // 2. Build the message — include media data URI if provided
  const message = buildAgentMessage(situationText, angle);

  // 3. Call /run_sse for streaming or /run for single response
  const response = await fetch(`${API_BASE}/run`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      appName: APP_NAME,
      userId,
      sessionId: sid,
      newMessage: {
        role: "user",
        parts: [{ text: message }],
      },
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Agent API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  return { result: data, sessionId: sid };
}

async function uploadAndRun({ dataUrl, mimeType, angle, context, userId }) {
  // Convert data URL to blob
  const res = await fetch(dataUrl);
  const blob = await res.blob();

  const formData = new FormData();
  formData.append("file", blob, `upload.${mimeType.split("/")[1]}`);
  formData.append("angle", angle);
  formData.append("context", context || "");
  formData.append("user_id", userId);

  const uploadRes = await fetch(`${API_BASE}/upload-media`, {
    method: "POST",
    body: formData,
  });

  if (!uploadRes.ok) throw new Error(`Upload failed: ${uploadRes.status}`);
  const uploadData = await uploadRes.json();

  // Now run the agent with the media context
  const situationText = `
[MULTIMODAL INPUT]
Media type: ${uploadData.mime_type}
Media data URI: ${uploadData.media_data_uri}
${context ? `User context: ${context}` : ""}
Lens angle: ${angle}

Please analyse this media and generate the perspective poem storyboard.
  `.trim();

  return runAgent({
    situationText,
    angle,
    userId,
    sessionId: null,
  });
}

async function createSession(userId, sessionId) {
  await fetch(`${API_BASE}/apps/${APP_NAME}/users/${userId}/sessions/${sessionId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  }).catch(() => {}); // session may already exist — ignore error
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function buildAgentMessage(situationText, angle) {
  return `
LENS: ${angle}

SITUATION:
${situationText}

Please:
1. Describe the original perspective (2-3 sentences)
2. Generate a 5-stanza poem storyboard from the other side
3. Return as structured JSON with keys: original_description, angle_label, frames, full_poem_text
  `.trim();
}

function generateUserId() {
  const id = "user_" + Math.random().toString(36).slice(2, 10);
  chrome.storage.local.set({ userId: id });
  return id;
}

function generateSessionId() {
  return "session_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);
}
