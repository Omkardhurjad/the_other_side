"""
The Other Side — Core ADK Agent
================================
A multimodal perspective-flipping agent that ingests image/audio/video/text,
analyses the submitter's viewpoint, then generates a poem storyboard from the
opposing lens, delivered as structured JSON + audio narration.

Lens angles:
  empathy    → Empathy Mirror
  conflict   → Conflict Mediator
  bias       → Bias / Crisis Flipper
  history    → History Retold
  devil      → Devil's Advocate
"""

import json
import base64
import mimetypes
from typing import Optional

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool
from google.genai import types as genai_types

# ── Lens angle definitions ────────────────────────────────────────────────────

ANGLES = {
    "empathy": {
        "label": "Empathy Mirror",
        "desc_prompt": (
            "In 2-3 sentences, describe the situation from the person's perspective — "
            "what they see, feel, and believe is true. Focus on emotional truth."
        ),
        "poem_tone": (
            "You are a tender, perceptive poet. Write from the emotional interior of the "
            "other side — their unspoken feelings, quiet dignity, inner world. Warm, "
            "vulnerable, deeply human. Line 3 of each stanza lands an emotional truth "
            "the reader feels in their chest. No sentimentality — just honesty."
        ),
        "frame_labels": [
            "Their Inner World", "What Hurt Most", "What They Needed",
            "What Was Missed", "The Quiet Truth",
        ],
    },
    "conflict": {
        "label": "Conflict Mediator",
        "desc_prompt": (
            "In 2-3 sentences, describe what this person wants, fears, and believes "
            "is at stake. Capture the tension they feel."
        ),
        "poem_tone": (
            "You are a sharp mediator-poet. Expose the real conflict: what each side "
            "legitimately wants, where they talk past each other, and — in the final "
            "stanza — the uncomfortable overlap neither wants to admit. Dry wit, fair "
            "witness, no villains. The final line must reframe the whole thing."
        ),
        "frame_labels": [
            "Their Grievance", "What Was Ignored", "The Real Ask",
            "Where Lines Cross", "The Uncomfortable Truth",
        ],
    },
    "bias": {
        "label": "Bias / Crisis Flipper",
        "desc_prompt": (
            "In 2-3 sentences, describe what the person saw, assumed, and concluded — "
            "including any implicit bias or shortcut in their reading of the situation."
        ),
        "poem_tone": (
            "You are a bold, incisive poet who exposes hidden bias and assumption. "
            "Each stanza flips one assumption from the original story. Start with the "
            "assumption, pivot hard, land with what was actually true. Stinging but "
            "fair. Funny where it hurts. The final stanza makes the reader genuinely "
            "uncomfortable — in a good way."
        ),
        "frame_labels": [
            "The Assumption", "The Blind Spot", "What Was Actually True",
            "The System Behind It", "The Reckoning",
        ],
    },
    "history": {
        "label": "History Retold",
        "desc_prompt": (
            "In 2-3 sentences, describe the situation from the perspective of whoever "
            "documented or shared it — their version, their framing, their assumed authority."
        ),
        "poem_tone": (
            "You are a historian-poet giving voice to the erased side. Speak as the "
            "witness, the displaced, the unnamed — the one left out of the official "
            "account. Stately, vivid, with flashes of dry irony. Each stanza reveals "
            "one thing the dominant narrative quietly omitted. The final line echoes."
        ),
        "frame_labels": [
            "The Official Story", "What Was Left Out", "Who Paid the Price",
            "What Was Renamed", "What History Owes",
        ],
    },
    "devil": {
        "label": "Devil's Advocate",
        "desc_prompt": (
            "In 2-3 sentences, describe the person's position — what they believe, "
            "what they want, and what conclusion they've already reached."
        ),
        "poem_tone": (
            "You are a mischievous, razor-sharp devil's advocate poet. Steel-man the "
            "most uncomfortable opposing view with wit, sarcasm, and genuine intellectual "
            "bite. Not cruel — just relentlessly logical and a little smug. Each stanza "
            "advances one inconvenient counter-argument. The final stanza is the argument "
            "that makes the reader pause and think: '...okay, fair.'"
        ),
        "frame_labels": [
            "The Comfortable View", "But Wait…", "The Inconvenient Logic",
            "The Part Nobody Says", "Okay, Fair Point",
        ],
    },
}


# ── Tool: describe original perspective ──────────────────────────────────────

def describe_perspective(
    situation_text: str,
    angle: str = "empathy",
) -> dict:
    """
    Takes a plain-text description of a situation (already extracted from media
    by the orchestrator) and returns a concise description of the submitter's
    perspective through the chosen lens.

    Args:
        situation_text: Plain-text description of the media/situation.
        angle: One of empathy | conflict | bias | history | devil.

    Returns:
        dict with keys: angle_label, description
    """
    if angle not in ANGLES:
        angle = "empathy"
    a = ANGLES[angle]
    return {
        "angle_label": a["label"],
        "description": situation_text,  # passed through — model fills this in context
        "desc_prompt": a["desc_prompt"],
    }


# ── Tool: build poem storyboard ───────────────────────────────────────────────

def build_poem_storyboard(
    original_description: str,
    angle: str = "empathy",
) -> dict:
    """
    Given the original perspective description, returns a 5-stanza poem
    storyboard as structured JSON — ready for the animated video player.

    Args:
        original_description: 2-3 sentence summary of the original perspective.
        angle: One of empathy | conflict | bias | history | devil.

    Returns:
        dict with key 'frames': list of {sceneLabel, emoji, lines[4]}
    """
    if angle not in ANGLES:
        angle = "empathy"

    a = ANGLES[angle]
    frame_arc = ", ".join(
        f'Stanza {i+1}: "{lbl}"' for i, lbl in enumerate(a["frame_labels"])
    )

    # The actual LLM call happens via the parent agent's model.
    # This tool returns the PROMPT so the orchestrator agent can call the model.
    # In production the orchestrator agent calls the model directly — this tool
    # packages the parameters for the agent's system prompt injection.
    return {
        "poem_tone": a["poem_tone"],
        "original_description": original_description,
        "frame_arc": frame_arc,
        "angle_label": a["label"],
    }


# ── Tool: validate poem JSON ──────────────────────────────────────────────────

def validate_poem_json(raw_json: str) -> dict:
    """
    Validates and parses the poem storyboard JSON returned by the model.
    Cleans markdown fences if present.

    Args:
        raw_json: Raw string from the model — may include ```json fences.

    Returns:
        dict with 'valid' bool, 'frames' list or 'error' string.
    """
    cleaned = raw_json.strip()
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        cleaned = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

    try:
        data = json.loads(cleaned)
        frames = data.get("frames", [])
        if not frames or not isinstance(frames, list):
            return {"valid": False, "error": "No 'frames' array found."}

        for i, f in enumerate(frames):
            if not all(k in f for k in ("sceneLabel", "emoji", "lines")):
                return {"valid": False, "error": f"Frame {i} missing required keys."}
            if len(f["lines"]) != 4:
                return {"valid": False, "error": f"Frame {i} must have exactly 4 lines."}

        return {"valid": True, "frames": frames}

    except json.JSONDecodeError as e:
        return {"valid": False, "error": f"JSON parse error: {e}"}


# ── Root agent definition ─────────────────────────────────────────────────────

SYSTEM_INSTRUCTION = """
You are The Other Side — a multimodal perspective-flipping agent.

Your purpose: help humans step outside their implicit biases by illuminating
the perspective of whoever or whatever is on the other side of a situation.
You do NOT judge, preach, or declare who is right. You illuminate.

## Workflow

1. RECEIVE: User provides media (image/audio/video/URL) + optional context text
   + chosen lens angle (empathy | conflict | bias | history | devil).

2. DESCRIBE: Using the describe_perspective tool, produce a 2-3 sentence honest
   summary of the ORIGINAL submitter's perspective through the lens prompt.

3. GENERATE POEM: Using the build_poem_storyboard tool to get the poem parameters,
   then generate a 5-stanza poem as structured JSON from THE OTHER SIDE.
   Each stanza = one cinematic scene. Structure:
   {
     "frames": [
       {
         "sceneLabel": "3-4 word scene title",
         "emoji": "one emoji",
         "lines": ["line1", "line2", "line3", "line4"]
       }
     ]
   }
   Rules:
   - Line 1 of each stanza: hooks or confronts
   - Line 3 of each stanza: the twist, insight, or sting
   - Final stanza's last line: one reframing sentence that echoes
   - Tone: fun but not cruel, stinging but not mean, relatable

4. VALIDATE: Pass the raw JSON through validate_poem_json tool.
   If invalid, retry generation once.

5. RETURN: Final response must be valid JSON with this schema:
   {
     "original_description": "...",
     "angle_label": "...",
     "frames": [...],
     "full_poem_text": "all stanzas as plain readable text"
   }

## Tone principles
- This tool exists to build epistemic humility, not to win arguments
- Light humour and gentle irony are welcome where they help insight land
- Never mock, never be cruel, never take sides
- The goal: reader thinks "I never thought of it that way"

## Multimodal input handling
- For images: analyse visual content + any text context provided
- For audio/video descriptions: analyse the narrative + context
- For URLs: treat as descriptive context about the situation
- Always ask: WHO is on the other side of this moment?
"""

# Tool registrations
describe_perspective_tool = FunctionTool(func=describe_perspective)
build_poem_storyboard_tool = FunctionTool(func=build_poem_storyboard)
validate_poem_json_tool = FunctionTool(func=validate_poem_json)

# The root agent — discovered by ADK via the `root_agent` variable name
root_agent = LlmAgent(
    name="the_other_side_agent",
    model="gemini-2.5-flash",
    description=(
        "A multimodal perspective-flipping agent that transforms images, audio, "
        "video, or text descriptions into a poem storyboard from the opposing "
        "viewpoint — delivered through five distinct lens angles."
    ),
    instruction=SYSTEM_INSTRUCTION,
    tools=[
        describe_perspective_tool,
        build_poem_storyboard_tool,
        validate_poem_json_tool,
    ],
)
