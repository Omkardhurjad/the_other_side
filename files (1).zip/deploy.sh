#!/usr/bin/env bash
# ============================================================
# deploy.sh — Deploy The Other Side Agent to Google Cloud Run
# ============================================================
# Usage:
#   chmod +x scripts/deploy.sh
#   ./scripts/deploy.sh
#
# Prerequisites:
#   - gcloud CLI authenticated: gcloud auth login
#   - Project set: gcloud config set project YOUR_PROJECT
#   - APIs enabled (script enables them if missing)
# ============================================================

set -euo pipefail

# ── Config (edit these) ───────────────────────────────────────────────────────
PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-your-project-id}"
REGION="${GOOGLE_CLOUD_LOCATION:-us-central1}"
SERVICE_NAME="the-other-side-agent"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

# ── Colours ───────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }

info "Deploying The Other Side Agent"
info "Project: ${PROJECT_ID} | Region: ${REGION}"

# ── Enable required APIs ──────────────────────────────────────────────────────
info "Enabling required Google Cloud APIs…"
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  aiplatform.googleapis.com \
  cloudtrace.googleapis.com \
  secretmanager.googleapis.com \
  sqladmin.googleapis.com \
  --project="${PROJECT_ID}" --quiet

success "APIs enabled"

# ── Build and push container ──────────────────────────────────────────────────
info "Building container image…"
gcloud builds submit \
  --tag "${IMAGE_NAME}:latest" \
  --project="${PROJECT_ID}" \
  .

success "Container built: ${IMAGE_NAME}:latest"

# ── Deploy to Cloud Run ───────────────────────────────────────────────────────
info "Deploying to Cloud Run…"
gcloud run deploy "${SERVICE_NAME}" \
  --image="${IMAGE_NAME}:latest" \
  --platform=managed \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --port=8080 \
  --cpu=1 \
  --memory=1Gi \
  --min-instances=0 \
  --max-instances=20 \
  --concurrency=80 \
  --timeout=300 \
  --set-env-vars="ENV=production,TRACE_TO_CLOUD=true,GOOGLE_CLOUD_PROJECT=${PROJECT_ID},GOOGLE_CLOUD_LOCATION=${REGION}" \
  --no-allow-unauthenticated \
  --quiet

SERVICE_URL=$(gcloud run services describe "${SERVICE_NAME}" \
  --region="${REGION}" --project="${PROJECT_ID}" \
  --format="value(status.url)")

success "Deployed! Service URL: ${SERVICE_URL}"

# ── Post-deploy verification ──────────────────────────────────────────────────
info "Verifying health endpoint…"
sleep 5

# Fetch with IAM token for authenticated service
TOKEN=$(gcloud auth print-identity-token)
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer ${TOKEN}" \
  "${SERVICE_URL}/health")

if [ "${HTTP_CODE}" = "200" ]; then
  success "Health check passed (HTTP ${HTTP_CODE})"
else
  warn "Health check returned HTTP ${HTTP_CODE} — check Cloud Run logs"
fi

echo ""
success "==================================================="
success " The Other Side Agent is live!"
success " URL: ${SERVICE_URL}"
success ""
success " Next steps:"
success " 1. Update chrome_extension/background.js API_BASE"
success "    to: ${SERVICE_URL}"
success " 2. Set GOOGLE_API_KEY in Secret Manager:"
success "    gcloud secrets create google-api-key --data-file=-"
success " 3. Load the chrome_extension/ folder in Chrome"
success "    chrome://extensions → Load unpacked"
success "==================================================="
