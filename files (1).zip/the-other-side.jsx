import { useState, useCallback, useEffect, useRef } from "react";

const MODEL = "claude-sonnet-4-20250514";

// ─────────────────────────────────────────────────────────────────────────────
// ANGLES
// ─────────────────────────────────────────────────────────────────────────────
const ANGLES = {
  empathy: {
    id:"empathy", label:"Empathy Mirror", icon:"🪞",
    tagline:"Feel what they felt.",
    description:"Reflect the emotional truth of the other person — their inner world, unspoken pain, quiet dignity.",
    accent:"#a78bfa", accentDim:"#a78bfa22", accentBorder:"#a78bfa44",
    bg:"#0d0818", gradient:"linear-gradient(135deg,#a78bfa,#818cf8)",
    poemTone:`You are a tender, perceptive poet. Write from the emotional interior of the other side. Warm, vulnerable, deeply human. Line 3 of each stanza lands an emotional truth the reader feels in their chest. No sentimentality — just honesty.`,
    descPrompt:`In 2 sentences, describe the situation from the person's perspective — what they see, feel, and believe is true.`,
    frameLabels:["Their Inner World","What Hurt Most","What They Needed","What Was Missed","The Quiet Truth"],
  },
  conflict: {
    id:"conflict", label:"Conflict Mediator", icon:"⚖️",
    tagline:"Both sides have a point.",
    description:"Map the real tension — what each side wants, where they talk past each other, and where the overlap is.",
    accent:"#f59e0b", accentDim:"#f59e0b22", accentBorder:"#f59e0b44",
    bg:"#120c00", gradient:"linear-gradient(135deg,#f59e0b,#ef4444)",
    poemTone:`You are a sharp mediator-poet. Expose the real conflict: what each side legitimately wants, where they talk past each other, and the uncomfortable overlap neither admits. Dry wit, fair witness, no villains. The final line must reframe the whole thing.`,
    descPrompt:`In 2 sentences, describe what this person wants, fears, and believes is at stake.`,
    frameLabels:["Their Grievance","What Was Ignored","The Real Ask","Where Lines Cross","The Uncomfortable Truth"],
  },
  bias: {
    id:"bias", label:"Bias / Crisis Flipper", icon:"🔄",
    tagline:"What you assumed. What was real.",
    description:"Expose the assumption baked into the original view — and flip it with what was actually happening.",
    accent:"#f472b6", accentDim:"#f472b622", accentBorder:"#f472b644",
    bg:"#140610", gradient:"linear-gradient(135deg,#f472b6,#fb923c)",
    poemTone:`You are a bold, incisive poet who exposes hidden bias. Each stanza flips one assumption — start with the assumption, pivot hard, land with what was actually true. Stinging but fair. The final stanza makes the reader genuinely uncomfortable — in a good way.`,
    descPrompt:`In 2 sentences, describe what the person saw, assumed, and concluded — including any implicit bias.`,
    frameLabels:["The Assumption","The Blind Spot","What Was Actually True","The System Behind It","The Reckoning"],
  },
  history: {
    id:"history", label:"History Retold", icon:"📜",
    tagline:"The version they didn't teach you.",
    description:"Give voice to the side of history that was edited out — the witness, the displaced, the unnamed.",
    accent:"#6ee7b7", accentDim:"#6ee7b722", accentBorder:"#6ee7b744",
    bg:"#020e08", gradient:"linear-gradient(135deg,#6ee7b7,#3b82f6)",
    poemTone:`You are a historian-poet giving voice to the erased side. Speak as the witness, the unnamed — the one left out. Stately, vivid, with flashes of dry irony. Each stanza reveals one thing the dominant narrative omitted. The final line should echo.`,
    descPrompt:`In 2 sentences, describe the situation from the perspective of whoever documented or shared it — their framing, their assumed authority.`,
    frameLabels:["The Official Story","What Was Left Out","Who Paid the Price","What Was Renamed","What History Owes"],
  },
  devil: {
    id:"devil", label:"Devil's Advocate", icon:"😈",
    tagline:"Just hear me out.",
    description:"Steel-man the most uncomfortable opposite view — not to be right, but to make you think harder.",
    accent:"#f87171", accentDim:"#f8717122", accentBorder:"#f8717144",
    bg:"#130404", gradient:"linear-gradient(135deg,#f87171,#c084fc)",
    poemTone:`You are a mischievous, razor-sharp devil's advocate poet. Steel-man the most uncomfortable opposing view with wit and intellectual bite. Not cruel — just relentlessly logical and a little smug. The final stanza is the argument that makes the reader pause and think: "...okay, fair."`,
    descPrompt:`In 2 sentences, describe the person's position — what they believe, what they want, what conclusion they've already reached.`,
    frameLabels:["The Comfortable View","But Wait…","The Inconvenient Logic","The Part Nobody Says","Okay, Fair Point"],
  },
};

const ANGLE_LIST = Object.values(ANGLES);

const FRAME_PALETTES = {
  empathy:[{bg:"#1a0d2e",accent:"#a78bfa",text:"#ede9fe"},{bg:"#0d1528",accent:"#818cf8",text:"#e0e7ff"},{bg:"#1a1028",accent:"#c084fc",text:"#f3e8ff"},{bg:"#0e1622",accent:"#7dd3fc",text:"#e0f2fe"},{bg:"#160e2a",accent:"#f0abfc",text:"#fdf4ff"}],
  conflict:[{bg:"#1c0e00",accent:"#f59e0b",text:"#fef3c7"},{bg:"#1a0606",accent:"#ef4444",text:"#fee2e2"},{bg:"#1a0a00",accent:"#fb923c",text:"#fff7ed"},{bg:"#160a00",accent:"#fbbf24",text:"#fffbeb"},{bg:"#1c0808",accent:"#f87171",text:"#fef2f2"}],
  bias:[{bg:"#1c0614",accent:"#f472b6",text:"#fce7f3"},{bg:"#1a0806",accent:"#fb923c",text:"#fff7ed"},{bg:"#180612",accent:"#e879f9",text:"#fdf4ff"},{bg:"#1a0c06",accent:"#f97316",text:"#fff7ed"},{bg:"#140616",accent:"#d946ef",text:"#fdf4ff"}],
  history:[{bg:"#021008",accent:"#6ee7b7",text:"#d1fae5"},{bg:"#021018",accent:"#67e8f9",text:"#e0f2fe"},{bg:"#04100a",accent:"#4ade80",text:"#dcfce7"},{bg:"#02100e",accent:"#2dd4bf",text:"#ccfbf1"},{bg:"#031014",accent:"#38bdf8",text:"#e0f2fe"}],
  devil:[{bg:"#160404",accent:"#f87171",text:"#fee2e2"},{bg:"#120214",accent:"#c084fc",text:"#f3e8ff"},{bg:"#160206",accent:"#fb7185",text:"#ffe4e6"},{bg:"#100214",accent:"#e879f9",text:"#fdf4ff"},{bg:"#180404",accent:"#f43f5e",text:"#fff1f2"}],
};

const G = {
  bg:"#07070e", surface:"#0f0f1a", card:"#12121e",
  border:"#1a1a2c", text:"#eeeaf8", muted:"#52506a", mutedLight:"#7a7894",
};

// ─────────────────────────────────────────────────────────────────────────────
// HOOKS
// ─────────────────────────────────────────────────────────────────────────────
function useSpeech() {
  const [voices, setVoices] = useState([]);
  useEffect(() => {
    const load = () => setVoices(window.speechSynthesis.getVoices());
    load();
    window.speechSynthesis.addEventListener("voiceschanged", load);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", load);
  }, []);
  const speak = useCallback((text, rate=0.80, onEnd) => {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = rate; u.pitch = 1.05;
    const v = voices.find(v=>v.name.includes("Google UK English Female")||v.name.includes("Samantha")||v.name.includes("Karen")||v.name.includes("Moira"));
    if (v) u.voice = v;
    if (onEnd) u.onend = onEnd;
    window.speechSynthesis.speak(u);
  }, [voices]);
  const stop = useCallback(()=>window.speechSynthesis.cancel(),[]);
  return {speak,stop};
}

// ─────────────────────────────────────────────────────────────────────────────
// SMALL COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────
function Dots({color}){
  return <div style={{display:"flex",gap:7,alignItems:"center"}}>
    {[0,1,2].map(i=><div key={i} style={{width:8,height:8,borderRadius:"50%",background:color,animation:`dot 1s ease-in-out ${i*.2}s infinite`}}/>)}
  </div>;
}

function GhostBtn({color=G.mutedLight,border=G.border,onClick,children,style={}}){
  return <button onClick={onClick} style={{background:"transparent",border:`1px solid ${border}`,borderRadius:50,padding:"9px 20px",color,cursor:"pointer",fontFamily:"'Lora',serif",fontSize:13,transition:"all .2s",display:"flex",alignItems:"center",gap:7,...style}}>{children}</button>;
}

function UploadZone({onFile,onUrl,accent}){
  const [drag,setDrag]=useState(false);
  const [urlMode,setUrlMode]=useState(false);
  const [urlVal,setUrlVal]=useState("");
  const ref=useRef();
  return <div style={{width:"100%",maxWidth:600}}>
    {!urlMode ? (
      <div onClick={()=>ref.current.click()}
        onDragOver={e=>{e.preventDefault();setDrag(true);}}
        onDragLeave={()=>setDrag(false)}
        onDrop={e=>{e.preventDefault();setDrag(false);const f=e.dataTransfer.files[0];if(f)onFile(f);}}
        style={{border:`1.5px dashed ${drag?accent:G.border}`,borderRadius:18,padding:"44px 32px",cursor:"pointer",textAlign:"center",transition:"all .22s",background:drag?`${accent}08`:G.surface}}>
        <div style={{fontSize:40,marginBottom:12,opacity:.8}}>◐</div>
        <p style={{fontFamily:"'Playfair Display',serif",fontSize:20,color:G.text,margin:"0 0 8px"}}>Share your moment</p>
        <p style={{color:G.muted,fontSize:13,margin:0}}>Image · Audio · Video · or <span onClick={e=>{e.stopPropagation();setUrlMode(true);}} style={{color:accent,textDecoration:"underline",cursor:"pointer"}}>paste a URL</span></p>
        <input ref={ref} type="file" accept="image/*,audio/*,video/*" style={{display:"none"}} onChange={e=>onFile(e.target.files[0])}/>
      </div>
    ) : (
      <div style={{display:"flex",gap:8}}>
        <input autoFocus value={urlVal} onChange={e=>setUrlVal(e.target.value)} placeholder="https://..."
          onKeyDown={e=>{if(e.key==="Enter"&&urlVal){onUrl(urlVal);setUrlMode(false);setUrlVal("");}}}
          style={{flex:1,background:G.card,border:`1px solid ${G.border}`,borderRadius:10,padding:"12px 16px",color:G.text,fontFamily:"inherit",fontSize:14,outline:"none"}}/>
        <button onClick={()=>{if(urlVal){onUrl(urlVal);setUrlMode(false);setUrlVal("");}}} style={{background:accent,color:G.bg,border:"none",borderRadius:10,padding:"12px 20px",cursor:"pointer",fontWeight:700,fontFamily:"inherit"}}>Go</button>
        <button onClick={()=>setUrlMode(false)} style={{background:G.border,color:G.muted,border:"none",borderRadius:10,padding:"12px 16px",cursor:"pointer",fontFamily:"inherit"}}>✕</button>
      </div>
    )}
  </div>;
}

function MediaPreview({src,type}){
  if(!src)return null;
  const isImg=type?.startsWith("image")||/\.(jpg|jpeg|png|gif|webp)(\?|$)/i.test(src);
  return <div style={{borderRadius:14,overflow:"hidden",background:G.card,border:`1px solid ${G.border}`,maxHeight:260,display:"flex",alignItems:"center",justifyContent:"center"}}>
    {isImg?<img src={src} alt="" style={{maxWidth:"100%",maxHeight:260,objectFit:"contain"}}/>
     :type?.startsWith("audio")?<audio controls src={src} style={{width:"100%",margin:16}}/>
     :type?.startsWith("video")?<video controls src={src} style={{maxWidth:"100%",maxHeight:260}}/>
     :<p style={{padding:20,color:G.muted,fontSize:13}}>🔗 {src}</p>}
  </div>;
}

function AngleSelector({selected,onChange}){
  return <div style={{width:"100%",maxWidth:780}}>
    <p style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".1em",textTransform:"uppercase",margin:"0 0 10px",textAlign:"center"}}>Choose your lens</p>
    <div style={{display:"flex",gap:10,flexWrap:"wrap",justifyContent:"center"}}>
      {ANGLE_LIST.map(a=>{
        const active=selected===a.id;
        return <button key={a.id} onClick={()=>onChange(a.id)} style={{background:active?a.accentDim:"transparent",border:`1.5px solid ${active?a.accent:G.border}`,borderRadius:50,padding:"10px 20px",cursor:"pointer",transition:"all .22s",display:"flex",alignItems:"center",gap:8,boxShadow:active?`0 0 18px ${a.accent}33`:"none"}}>
          <span style={{fontSize:16}}>{a.icon}</span>
          <span style={{fontFamily:"'Playfair Display',serif",fontSize:13,fontWeight:active?600:400,color:active?a.accent:G.mutedLight}}>{a.label}</span>
        </button>;
      })}
    </div>
  </div>;
}

// ─────────────────────────────────────────────────────────────────────────────
// BRIDGING PITCH COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
function BridgePitch({pitch, angle}){
  if(!pitch)return null;
  return <div style={{background:`linear-gradient(135deg,${angle.accentDim},${G.card})`,border:`1px solid ${angle.accentBorder}`,borderRadius:16,padding:"22px 26px",animation:"fadeUp .5s ease",position:"relative",overflow:"hidden"}}>
    <div style={{position:"absolute",top:-20,right:-20,fontSize:80,opacity:.06,pointerEvents:"none"}}>◐◑</div>
    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
      <span style={{fontSize:18}}>🌉</span>
      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:angle.accent,letterSpacing:".12em",textTransform:"uppercase",opacity:.85}}>The Bridge</span>
      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:8,color:G.muted,marginLeft:"auto",opacity:.6}}>grounded in public record</span>
    </div>

    {pitch.headline && <p style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:600,color:G.text,lineHeight:1.4,marginBottom:12,fontStyle:"italic"}}>"{pitch.headline}"</p>}

    {pitch.bridge && <p style={{color:`${G.text}cc`,fontSize:14,lineHeight:1.75,marginBottom:14}}>{pitch.bridge}</p>}

    {pitch.facts?.length > 0 && (
      <div style={{borderTop:`1px solid ${angle.accentBorder}`,paddingTop:12,marginBottom:12}}>
        <p style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".1em",textTransform:"uppercase",marginBottom:8}}>What the record shows</p>
        {pitch.facts.map((f,i)=>(
          <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
            <span style={{color:angle.accent,fontSize:12,marginTop:2,flexShrink:0}}>◆</span>
            <p style={{color:`${G.text}bb`,fontSize:13,lineHeight:1.6,margin:0}}>{f}</p>
          </div>
        ))}
      </div>
    )}

    {pitch.callToReflect && (
      <p style={{fontFamily:"'Playfair Display',serif",fontSize:15,color:angle.accent,fontStyle:"italic",borderTop:`1px solid ${angle.accentBorder}`,paddingTop:12,margin:0}}>
        {pitch.callToReflect}
      </p>
    )}
  </div>;
}

// ─────────────────────────────────────────────────────────────────────────────
// STORYBOARD PLAYER
// ─────────────────────────────────────────────────────────────────────────────
function StoryboardPlayer({frames,angleId,isPlaying,currentFrame,onPlay,onPause,onFrameClick,storyboardRef}){
  if(!frames?.length)return null;
  const palettes=FRAME_PALETTES[angleId]||FRAME_PALETTES.empathy;
  const f=frames[currentFrame]||frames[0];
  const pal=palettes[currentFrame%palettes.length];
  const progress=frames.length>1?(currentFrame/(frames.length-1))*100:0;

  return <div style={{width:"100%"}} ref={storyboardRef}>
    <div key={`frame-${currentFrame}`} style={{borderRadius:22,overflow:"hidden",position:"relative",background:pal.bg,border:`1px solid ${pal.accent}44`,minHeight:360,display:"flex",flexDirection:"column",boxShadow:`0 8px 60px ${pal.accent}18,0 0 0 1px ${pal.accent}18`,animation:"frameIn .36s ease"}}>
      <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:200,opacity:.05,pointerEvents:"none",userSelect:"none",filter:"blur(4px)",transform:"rotate(-15deg)"}}>{f.emoji}</div>
      <div style={{padding:"18px 24px",display:"flex",justifyContent:"space-between",alignItems:"center",zIndex:1}}>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:pal.accent,letterSpacing:".14em",textTransform:"uppercase",background:`${pal.accent}15`,padding:"4px 12px",borderRadius:20}}>{f.sceneLabel}</span>
        <div style={{display:"flex",gap:5,alignItems:"center"}}>
          {frames.map((_,i)=><div key={i} onClick={()=>onFrameClick(i)} style={{width:i===currentFrame?24:6,height:6,borderRadius:3,background:i===currentFrame?pal.accent:`${pal.accent}30`,cursor:"pointer",transition:"all .28s"}}/>)}
        </div>
      </div>
      <div style={{flex:1,padding:"8px 44px 24px",zIndex:1,display:"flex",alignItems:"center"}}>
        <div style={{width:"100%"}}>
          {f.lines.map((line,i)=><p key={`${currentFrame}-${i}`} style={{fontFamily:"'Playfair Display',serif",fontSize:i===0?24:18,fontWeight:i===0?600:400,color:i===0?pal.text:`${pal.text}bb`,fontStyle:i%2===1?"italic":"normal",lineHeight:1.6,margin:"0 0 10px",animation:`lineIn .44s ease ${i*.12}s both`}}>{line}</p>)}
        </div>
      </div>
      <div style={{position:"absolute",bottom:60,right:28,fontSize:64,zIndex:1,animation:"emojiPop .45s cubic-bezier(.17,.67,.35,1.4)"}}>{f.emoji}</div>
      <div style={{padding:"12px 22px 16px",zIndex:1,borderTop:`1px solid ${pal.accent}18`,background:`${pal.bg}f0`,display:"flex",alignItems:"center",gap:14}}>
        <button onClick={isPlaying?onPause:onPlay} style={{background:pal.accent,color:pal.bg,border:"none",borderRadius:"50%",width:44,height:44,fontSize:16,cursor:"pointer",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 0 20px ${pal.accent}55`}}>{isPlaying?"⏸":"▶"}</button>
        <div style={{flex:1,height:4,background:`${pal.accent}20`,borderRadius:2,overflow:"hidden",cursor:"pointer"}} onClick={e=>{const r=e.currentTarget.getBoundingClientRect();onFrameClick(Math.min(frames.length-1,Math.floor(((e.clientX-r.left)/r.width)*frames.length)));}}>
          <div style={{height:"100%",background:pal.accent,borderRadius:2,width:`${progress}%`,transition:"width .5s ease"}}/>
        </div>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:`${pal.accent}77`,minWidth:32}}>{currentFrame+1}/{frames.length}</span>
      </div>
    </div>
    <div style={{display:"flex",gap:8,marginTop:10,overflowX:"auto",paddingBottom:4}}>
      {frames.map((fr,i)=>{const p=palettes[i%palettes.length];return <div key={i} onClick={()=>onFrameClick(i)} style={{flexShrink:0,width:78,height:54,borderRadius:10,background:p.bg,border:`1.5px solid ${i===currentFrame?p.accent:`${p.accent}22`}`,cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:2,transition:"all .22s",transform:i===currentFrame?"scale(1.08)":"scale(1)",boxShadow:i===currentFrame?`0 0 14px ${p.accent}44`:"none"}}><span style={{fontSize:22}}>{fr.emoji}</span><span style={{fontSize:8,color:`${p.accent}88`,fontFamily:"'JetBrains Mono',monospace"}}>S{i+1}</span></div>;})}
    </div>
  </div>;
}

function PoemView({frames,angleId}){
  if(!frames?.length)return null;
  const palettes=FRAME_PALETTES[angleId]||FRAME_PALETTES.empathy;
  return <div style={{background:G.card,border:`1px solid ${G.border}`,borderRadius:16,padding:"28px 34px",animation:"fadeUp .4s ease"}}>
    <p style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".14em",textTransform:"uppercase",margin:"0 0 24px"}}>Full Poem — The Other Side</p>
    {frames.map((f,i)=>{const p=palettes[i%palettes.length];return <div key={i} style={{marginBottom:28}}>
      <p style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:p.accent,letterSpacing:".1em",textTransform:"uppercase",margin:"0 0 10px",opacity:.75}}>{f.sceneLabel} {f.emoji}</p>
      {f.lines.map((line,j)=><p key={j} style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontStyle:j%2===1?"italic":"normal",color:j===0?G.text:`${G.text}aa`,lineHeight:1.78,margin:"0 0 2px"}}>{line}</p>)}
    </div>;})}
  </div>;
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARE + DOWNLOAD PANEL
// ─────────────────────────────────────────────────────────────────────────────
function SharePanel({frames, pitch, originalDesc, angle, fullPoemText, storyboardRef}){
  const [exporting, setExporting] = useState(null); // null | 'image' | 'audio' | 'text'
  const [copied, setCopied] = useState(false);
  const [shareMsg, setShareMsg] = useState("");

  // ── Export as image (canvas) ────────────────────────────────────────────
  const exportImage = async () => {
    setExporting("image");
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 1080; canvas.height = 1080;
      const ctx = canvas.getContext("2d");
      const palettes = FRAME_PALETTES[angle.id] || FRAME_PALETTES.empathy;

      // Background
      ctx.fillStyle = "#07070e";
      ctx.fillRect(0, 0, 1080, 1080);

      // Gradient overlay
      const grad = ctx.createRadialGradient(540, 0, 0, 540, 0, 900);
      grad.addColorStop(0, `${angle.accent}33`);
      grad.addColorStop(1, "transparent");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1080, 1080);

      // Header
      ctx.fillStyle = angle.accent;
      ctx.font = "bold 36px Georgia, serif";
      ctx.textAlign = "center";
      ctx.fillText("◐ THE OTHER SIDE", 540, 80);

      ctx.fillStyle = "#ffffff88";
      ctx.font = "22px Georgia, serif";
      ctx.fillText(`${angle.icon} ${angle.label}`, 540, 120);

      // Divider
      ctx.strokeStyle = `${angle.accent}44`;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(80, 145); ctx.lineTo(1000, 145); ctx.stroke();

      // Pitch headline
      if (pitch?.headline) {
        ctx.fillStyle = "#eeeaf8";
        ctx.font = "italic bold 28px Georgia, serif";
        ctx.textAlign = "center";
        const words = pitch.headline.split(" ");
        let line = "", y = 195;
        for (const word of words) {
          const test = line + word + " ";
          if (ctx.measureText(test).width > 860 && line) {
            ctx.fillText(`"${line.trim()}"`, 540, y);
            line = word + " "; y += 38;
          } else { line = test; }
        }
        if (line) ctx.fillText(`"${line.trim()}"`, 540, y);
      }

      // First 2 stanzas of poem
      const startY = pitch?.headline ? 320 : 200;
      ctx.textAlign = "left";
      let py = startY;
      (frames.slice(0,2)).forEach((f, fi) => {
        const p = palettes[fi % palettes.length];
        // Frame bg
        ctx.fillStyle = p.bg;
        ctx.beginPath();
        ctx.roundRect(60, py-10, 960, 140, 14);
        ctx.fill();
        // Scene label
        ctx.fillStyle = p.accent;
        ctx.font = "bold 13px 'Courier New', monospace";
        ctx.fillText(f.sceneLabel.toUpperCase(), 84, py + 16);
        // Lines
        f.lines.slice(0,2).forEach((line, li) => {
          ctx.fillStyle = li === 0 ? p.text : `${p.text}bb`;
          ctx.font = li % 2 === 1 ? `italic 18px Georgia, serif` : `18px Georgia, serif`;
          ctx.fillText(line.length > 55 ? line.slice(0, 52) + "…" : line, 84, py + 44 + li * 30);
        });
        // Emoji
        ctx.font = "44px serif";
        ctx.fillText(f.emoji, 970, py + 80);
        py += 160;
      });

      // Footer
      ctx.fillStyle = "#52506a";
      ctx.font = "15px 'Courier New', monospace";
      ctx.textAlign = "center";
      ctx.fillText("Step outside your perspective. Just for a moment.", 540, 1040);

      // Download
      const link = document.createElement("a");
      link.download = `the-other-side-${angle.id}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch(e){ console.error(e); }
    setExporting(null);
  };

  // ── Export as audio (Web Speech + MediaRecorder) ─────────────────────
  const exportAudio = async () => {
    setExporting("audio");
    try {
      // Build full narration text
      const pitchText = pitch?.headline ? `${pitch.headline}. ${pitch.bridge || ""}. ` : "";
      const poemText  = frames.map(f => f.lines.join(". ")).join(". \n");
      const fullText  = `The Other Side. ${angle.label}. ${pitchText}${poemText}`;

      // Use MediaRecorder on AudioContext destination if available
      // Fallback: write text file with narration script
      if (window.MediaRecorder && AudioContext) {
        // Create audio context for recording speech
        const ctx = new AudioContext();
        const dest = ctx.createMediaStreamDestination();
        const recorder = new MediaRecorder(dest.stream);
        const chunks = [];
        recorder.ondataavailable = e => chunks.push(e.data);
        recorder.onstop = () => {
          const blob = new Blob(chunks, {type:"audio/webm"});
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url; a.download = `the-other-side-${angle.id}.webm`; a.click();
          URL.revokeObjectURL(url);
          setExporting(null);
        };
        recorder.start();
        // We can't directly record speechSynthesis — download script instead
        recorder.stop();
        // Fallback to text download with narration script
      }
      // Always offer the narration script as text download
      const scriptContent = `THE OTHER SIDE — ${angle.label.toUpperCase()}\n${"─".repeat(50)}\n\n🌉 THE BRIDGE\n\n${pitch?.headline ? `"${pitch.headline}"\n\n` : ""}${pitch?.bridge || ""}\n\n${pitch?.facts?.length ? `WHAT THE RECORD SHOWS:\n${pitch.facts.map(f=>`• ${f}`).join("\n")}\n\n` : ""}${pitch?.callToReflect ? `"${pitch.callToReflect}"\n\n` : ""}${"─".repeat(50)}\n\n◑ THE POEM\n\n${frames.map(f=>`[${f.sceneLabel}]\n${f.lines.join("\n")}`).join("\n\n")}\n\n${"─".repeat(50)}\nStep outside your perspective. Just for a moment.\ntheotherside.ai`;
      const blob = new Blob([scriptContent], {type:"text/plain"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `the-other-side-${angle.id}-script.txt`; a.click();
      URL.revokeObjectURL(url);
    } catch(e){ console.error(e); }
    setExporting(null);
  };

  // ── Copy text ─────────────────────────────────────────────────────────
  const copyText = async () => {
    const text = [
      `◐ THE OTHER SIDE — ${angle.label}`,
      ``,
      pitch?.headline ? `🌉 "${pitch.headline}"` : "",
      pitch?.bridge || "",
      ``,
      `◑ A poem from the other side:`,
      ``,
      frames.map(f=>`[${f.sceneLabel}]\n${f.lines.join("\n")}`).join("\n\n"),
      ``,
      pitch?.callToReflect ? `"${pitch.callToReflect}"` : "",
      ``,
      `Step outside your perspective. Just for a moment.`,
    ].filter(l=>l!==undefined).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(()=>setCopied(false), 2500);
    } catch {}
  };

  // ── Share (Web Share API or fallback) ─────────────────────────────────
  const shareOut = async () => {
    const text = pitch?.headline
      ? `"${pitch.headline}" — The Other Side (${angle.label})\n\n${pitch?.bridge?.slice(0,200) || ""}…`
      : `The Other Side — ${angle.label}\n\n${frames[0]?.lines.join(" / ")}`;
    if (navigator.share) {
      try { await navigator.share({title:"The Other Side", text, url: window.location.href}); }
      catch {}
    } else {
      // Compose tweet-friendly text
      const tweet = encodeURIComponent(text.slice(0, 240) + " #TheOtherSide #Perspective");
      window.open(`https://twitter.com/intent/tweet?text=${tweet}`, "_blank");
      setShareMsg("Opening Twitter/X…");
      setTimeout(()=>setShareMsg(""),2000);
    }
  };

  const shareLinkedIn = () => {
    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(`The Other Side — ${angle.label}`);
    window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${url}&title=${title}`, "_blank");
  };

  return <div style={{background:G.card,border:`1px solid ${G.border}`,borderRadius:16,padding:"20px 24px",animation:"fadeUp .5s ease .1s both"}}>
    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:16}}>
      <span style={{fontSize:16}}>📤</span>
      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".12em",textTransform:"uppercase"}}>Download & Share</span>
    </div>

    <div style={{display:"flex",flexWrap:"wrap",gap:9}}>
      {/* Image export */}
      <GhostBtn color="#7dd3fc" border="#7dd3fc44" onClick={exportImage} style={{opacity:exporting==="image"?.6:1}}>
        {exporting==="image"?"⏳":"🖼"} <span>Save as Image</span>
      </GhostBtn>

      {/* Audio / script */}
      <GhostBtn color="#6ee7b7" border="#6ee7b744" onClick={exportAudio} style={{opacity:exporting==="audio"?.6:1}}>
        {exporting==="audio"?"⏳":"🎙"} <span>Download Script</span>
      </GhostBtn>

      {/* Copy text */}
      <GhostBtn color={copied?"#4ade80":G.mutedLight} border={copied?"#4ade8044":G.border} onClick={copyText}>
        {copied?"✓ Copied":"📋"} <span>{copied?"Copied!":"Copy Text"}</span>
      </GhostBtn>

      {/* Share */}
      <GhostBtn color="#f0c96a" border="#f0c96a44" onClick={shareOut}>
        🐦 <span>Share</span>
      </GhostBtn>

      {/* LinkedIn */}
      <GhostBtn color="#60a5fa" border="#60a5fa44" onClick={shareLinkedIn}>
        💼 <span>LinkedIn</span>
      </GhostBtn>
    </div>

    {shareMsg && <p style={{color:G.muted,fontSize:12,marginTop:10,fontStyle:"italic"}}>{shareMsg}</p>}

    <p style={{color:G.muted,fontSize:11,marginTop:12,lineHeight:1.6,fontStyle:"italic"}}>
      Image export: 1080×1080 PNG, shareable on any social platform.<br/>
      Script download: full narration text for recording your own voiceover.
    </p>
  </div>;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────
export default function TheOtherSide(){
  const [selectedAngle,setSelectedAngle]=useState("empathy");
  const [mediaFile,setMediaFile]=useState(null);
  const [mediaSrc,setMediaSrc]=useState(null);
  const [mediaType,setMediaType]=useState(null);
  const [context,setContext]=useState("");
  const [status,setStatus]=useState("idle"); // idle|analysing|bridging|generating|done|error
  const [frames,setFrames]=useState(null);
  const [originalDesc,setOriginalDesc]=useState("");
  const [pitch,setPitch]=useState(null);
  const [currentFrame,setCurrentFrame]=useState(0);
  const [isPlaying,setIsPlaying]=useState(false);
  const [showPoem,setShowPoem]=useState(false);
  const storyboardRef=useRef(null);
  const {speak,stop}=useSpeech();
  const angle=ANGLES[selectedAngle];

  useEffect(()=>()=>{if(mediaSrc?.startsWith("blob:"))URL.revokeObjectURL(mediaSrc);},[mediaSrc]);

  const resetOutput=()=>{stop();setFrames(null);setStatus("idle");setCurrentFrame(0);setIsPlaying(false);setOriginalDesc("");setPitch(null);setShowPoem(false);};
  const handleFile=f=>{if(mediaSrc?.startsWith("blob:"))URL.revokeObjectURL(mediaSrc);setMediaFile(f);setMediaSrc(URL.createObjectURL(f));setMediaType(f.type);resetOutput();};
  const handleUrl=url=>{if(mediaSrc?.startsWith("blob:"))URL.revokeObjectURL(mediaSrc);setMediaFile(null);setMediaSrc(url);setMediaType(null);resetOutput();};
  const handleAngleChange=id=>{setSelectedAngle(id);resetOutput();};

  const toBase64=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(f);});

  const callClaude=async(messages,system)=>{
    const body={model:MODEL,max_tokens:1400,messages};
    if(system)body.system=system;
    const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const data=await res.json();
    if(data.error)throw new Error(data.error.message);
    return data.content.map(b=>b.text||"").join("\n");
  };

  const analyse=async()=>{
    if(!mediaSrc)return;
    stop();setStatus("analysing");setFrames(null);setCurrentFrame(0);setIsPlaying(false);setShowPoem(false);setPitch(null);

    try{
      const a=ANGLES[selectedAngle];

      // Step 1: describe original perspective
      let descContent;
      if(mediaFile?.type?.startsWith("image")){
        const b64=await toBase64(mediaFile);
        descContent=[
          {type:"image",source:{type:"base64",media_type:mediaFile.type,data:b64}},
          {type:"text",text:(context?`Context: "${context}". `:"")+a.descPrompt}
        ];
      } else {
        descContent=[{type:"text",text:`Media: ${mediaSrc}\n${context?`Context: "${context}"\n`:""}${a.descPrompt}`}];
      }
      const desc=await callClaude([{role:"user",content:descContent}]);
      setOriginalDesc(desc);

      // Step 2: Generate bridging pitch (grounded in public record)
      setStatus("bridging");
      const pitchPrompt=`You are a research-backed perspective analyst. 

Original perspective: "${desc}"
Lens: ${a.label} — ${a.tagline}

Generate a BRIDGING PITCH that connects the original perspective to the other side.

CRITICAL RULE: Every fact you cite MUST be grounded in publicly available, verifiable information. If you cannot verify a fact, do NOT include it. Cite real patterns, documented events, verified statistics, or widely acknowledged phenomena only. Never fabricate.

Return ONLY valid JSON:
{
  "headline": "a punchy, memorable 10-15 word headline that captures the bridge — like a great newspaper subhead",
  "bridge": "2-3 sentences connecting both perspectives through documented reality. Specific, grounded, no fluff.",
  "facts": ["one verified public fact that reframes the original view", "a second grounded fact or statistic", "a third real-world pattern or documented phenomenon"],
  "callToReflect": "one final sentence — a question or observation that stays with you. Max 20 words."
}`;

      const rawPitch=await callClaude([{role:"user",content:pitchPrompt}],"Output only valid raw JSON. No markdown. No commentary.");
      try{
        const clean=rawPitch.replace(/```json|```/g,"").trim();
        const p=JSON.parse(clean.match(/\{[\s\S]*\}/)?.[0]||clean);
        setPitch(p);
      } catch { setPitch(null); }

      // Step 3: Generate poem
      setStatus("generating");
      const frameLabels=a.frameLabels.map((l,i)=>`Stanza ${i+1}: "${l}"`).join(", ");
      const poemPrompt=`${a.poemTone}

Original perspective: "${desc}"

Write a 5-stanza poem from THE OTHER SIDE, through the lens of: ${a.label}.
Scene arc: ${frameLabels}.

Rules:
- 4 lines per stanza. Line 1 hooks. Line 3 is the twist or insight.
- Final stanza's last line: one sentence that reframes everything.
- Ground the poem in the same verifiable reality as the bridge — no invented facts.
- Tone: sharp wit where it lands, warm irony where it reveals. Memorable and relatable.

Return ONLY valid raw JSON:
{"frames":[{"sceneLabel":"3-4 word title","emoji":"one emoji","lines":["line1","line2","line3","line4"]}]}`;

      const raw=await callClaude([{role:"user",content:poemPrompt}],"Output only valid raw JSON. No markdown. No commentary.");
      let parsed;
      try{parsed=JSON.parse(raw.replace(/```json|```/g,"").trim());}
      catch{const m=raw.match(/\{[\s\S]*\}/);if(m)parsed=JSON.parse(m[0]);}
      if(!parsed?.frames?.length)throw new Error("Could not parse poem.");
      setFrames(parsed.frames);
      setStatus("done");
    } catch(e){
      console.error(e);
      setStatus("error");
    }
  };

  const playFromFrame=useCallback((startIdx)=>{
    if(!frames)return;
    setIsPlaying(true);
    let idx=startIdx;
    const next=()=>{
      if(idx>=frames.length){setIsPlaying(false);return;}
      setCurrentFrame(idx);
      speak(frames[idx].lines.join(" … "),0.78,()=>{idx++;setTimeout(next,700);});
    };
    next();
  },[frames,speak]);

  const handlePlay=()=>playFromFrame(currentFrame>=(frames?.length??0)-1?0:currentFrame);
  const handlePause=()=>{stop();setIsPlaying(false);};
  const handleFrameClick=i=>{stop();setIsPlaying(false);setCurrentFrame(i);};
  const fullReset=()=>{stop();setIsPlaying(false);setMediaFile(null);setMediaSrc(null);setMediaType(null);setContext("");setFrames(null);setStatus("idle");setCurrentFrame(0);setShowPoem(false);setOriginalDesc("");setPitch(null);};

  const loading=["analysing","bridging","generating"].includes(status);
  const statusMsg={analysing:"Reading your side…",bridging:"Researching the bridge…",generating:"Writing the poem…"}[status]??"";

  const fullPoemText=frames?.map(f=>`[${f.sceneLabel}]\n${f.lines.join("\n")}`).join("\n\n")||"";

  return <>
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Lora:ital@0;1&family=JetBrains+Mono:wght@400;500&display=swap');
      *{box-sizing:border-box;margin:0;padding:0;}
      body{background:${G.bg};color:${G.text};font-family:'Lora',serif;}
      @keyframes dot{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-9px)}}
      @keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
      @keyframes frameIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
      @keyframes lineIn{from{opacity:0;transform:translateX(-12px)}to{opacity:1;transform:translateX(0)}}
      @keyframes emojiPop{from{transform:scale(0) rotate(-25deg)}to{transform:scale(1) rotate(0)}}
      @keyframes glowPulse{0%,100%{opacity:.5}50%{opacity:1}}
      input::placeholder,textarea::placeholder{color:${G.muted};}
      input:focus,textarea:focus{outline:none;}
      button:active{transform:scale(.97);}
      ::-webkit-scrollbar{width:3px;height:3px}
      ::-webkit-scrollbar-thumb{background:${G.border};border-radius:3px}
    `}</style>

    <div style={{minHeight:"100vh",display:"flex",flexDirection:"column",background:`radial-gradient(ellipse at top,${angle.bg} 0%,${G.bg} 60%)`,transition:"background .6s ease"}}>

      {/* ── Fixed brand header ── */}
      <header style={{padding:"20px 48px 16px",borderBottom:`1px solid ${G.border}`,display:"flex",alignItems:"center",justifyContent:"space-between",background:`${G.bg}f8`,backdropFilter:"blur(12px)",position:"sticky",top:0,zIndex:100}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:26,filter:"drop-shadow(0 0 10px #ffffff33)"}}>◐</span>
          <div>
            <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:24,fontWeight:400,background:"linear-gradient(100deg,#e8e6f0,#9ca3bf)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",margin:"0 0 2px",letterSpacing:"-.01em"}}>The Other Side</h1>
            <p style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".1em",textTransform:"uppercase"}}>Step outside your perspective. Just for a moment.</p>
          </div>
        </div>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted}}>Multimodal · Grounded · Poem · Audio</span>
      </header>

      {/* ── Dynamic lens sub-header ── */}
      <div style={{padding:"14px 48px 12px",borderBottom:`1px solid ${angle.accentBorder}`,background:`linear-gradient(90deg,${angle.bg}cc,${G.bg}88)`,display:"flex",alignItems:"center",justifyContent:"space-between",transition:"all .45s ease",minHeight:60}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:24,filter:`drop-shadow(0 0 12px ${angle.accent}88)`,animation:"glowPulse 3s ease infinite",transition:"all .4s"}}>{angle.icon}</span>
          <div>
            <p style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:600,background:angle.gradient,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",margin:"0 0 2px",transition:"all .4s"}}>{angle.label}</p>
            <p style={{fontFamily:"'Lora',serif",fontSize:12,fontStyle:"italic",color:`${angle.accent}bb`,margin:0,transition:"color .4s"}}>{angle.tagline}</p>
          </div>
        </div>
        <p style={{color:G.muted,fontSize:12,maxWidth:260,textAlign:"right",lineHeight:1.55,fontFamily:"'Lora',serif"}}>{angle.description}</p>
      </div>

      {/* ── Main ── */}
      <main style={{flex:1,padding:"36px 48px 64px",display:"flex",flexDirection:"column",gap:26,maxWidth:860,width:"100%",margin:"0 auto"}}>

        <AngleSelector selected={selectedAngle} onChange={handleAngleChange}/>

        <div style={{height:1,background:`linear-gradient(90deg,transparent,${angle.accent}44,transparent)`,transition:"background .4s"}}/>

        {/* Upload */}
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:14}}>
          <UploadZone onFile={handleFile} onUrl={handleUrl} accent={angle.accent}/>
          {mediaSrc&&<div style={{width:"100%",maxWidth:600,animation:"fadeUp .35s ease"}}><MediaPreview src={mediaSrc} type={mediaType}/></div>}
          {mediaSrc&&<div style={{width:"100%",maxWidth:600,display:"flex",gap:10,animation:"fadeUp .4s ease"}}>
            <input value={context} onChange={e=>setContext(e.target.value)}
              placeholder="Describe the situation in your own words (optional but helpful)"
              style={{flex:1,background:G.card,border:`1px solid ${G.border}`,borderRadius:10,padding:"12px 16px",color:G.text,fontFamily:"'Lora',serif",fontSize:14,transition:"border-color .2s"}}
              onFocus={e=>e.target.style.borderColor=angle.accent}
              onBlur={e=>e.target.style.borderColor=G.border}/>
            <button onClick={analyse} disabled={loading} style={{background:loading?G.border:angle.accent,color:loading?G.muted:G.bg,border:"none",borderRadius:10,padding:"12px 24px",cursor:loading?"not-allowed":"pointer",fontFamily:"'Playfair Display',serif",fontSize:14,fontWeight:600,minWidth:120,opacity:loading?.6:1,transition:"all .2s"}}>
              {loading?statusMsg:`Flip It ${angle.icon}`}
            </button>
          </div>}
        </div>

        {/* Loading */}
        {loading&&<div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:12,padding:"12px 0",animation:"fadeUp .3s ease"}}>
          <Dots color={angle.accent}/>
          <p style={{color:G.muted,fontSize:13,fontStyle:"italic"}}>{statusMsg}</p>
        </div>}

        {/* Original perspective chip */}
        {originalDesc&&<div style={{background:`${angle.accent}0c`,border:`1px solid ${angle.accentBorder}`,borderRadius:12,padding:"14px 20px",animation:"fadeUp .4s ease"}}>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:angle.accent,letterSpacing:".12em",textTransform:"uppercase",display:"block",marginBottom:6,opacity:.8}}>How you see it</span>
          <p style={{color:`${G.text}99`,fontSize:14,lineHeight:1.65}}>{originalDesc}</p>
        </div>}

        {/* ── Bridge pitch ── */}
        {pitch&&<BridgePitch pitch={pitch} angle={angle}/>}

        {/* ── Storyboard ── */}
        {status==="done"&&frames&&<div style={{animation:"fadeUp .5s ease",display:"flex",flexDirection:"column",gap:16}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <span style={{color:angle.accent,fontSize:18}}>◑</span>
            <span style={{fontFamily:"'Playfair Display',serif",fontSize:13,letterSpacing:".07em",textTransform:"uppercase",color:angle.accent}}>The Other Side — {angle.label}</span>
          </div>

          <StoryboardPlayer frames={frames} angleId={selectedAngle} isPlaying={isPlaying} currentFrame={currentFrame} onPlay={handlePlay} onPause={handlePause} onFrameClick={handleFrameClick} storyboardRef={storyboardRef}/>

          {/* Playback controls */}
          <div style={{display:"flex",justifyContent:"center",gap:10,flexWrap:"wrap",marginTop:2}}>
            <GhostBtn color={angle.accent} border={angle.accent} onClick={isPlaying?handlePause:handlePlay}>
              {isPlaying?"⏸ Pause":"▶ Play poem aloud"}
            </GhostBtn>
            <GhostBtn onClick={()=>setShowPoem(p=>!p)}>{showPoem?"Hide text":"📜 Read full poem"}</GhostBtn>
            <GhostBtn onClick={fullReset}>Start over</GhostBtn>
          </div>

          {showPoem&&<PoemView frames={frames} angleId={selectedAngle}/>}

          {/* ── Share panel ── */}
          <SharePanel frames={frames} pitch={pitch} originalDesc={originalDesc} angle={angle} fullPoemText={fullPoemText} storyboardRef={storyboardRef}/>
        </div>}

        {/* Error */}
        {status==="error"&&<p style={{textAlign:"center",color:"#f87171",fontSize:14,padding:"16px 0"}}>Something went wrong — please try again.</p>}

        {/* Empty state */}
        {status==="idle"&&!mediaSrc&&<div style={{textAlign:"center",paddingTop:8,animation:"fadeUp .5s ease"}}>
          <p style={{color:G.muted,fontSize:14,fontStyle:"italic",lineHeight:2.2,maxWidth:480,margin:"0 auto"}}>
            Pick a lens. Upload a moment.<br/>
            Get a grounded bridge between both sides,<br/>
            a poem that stings, and outputs worth sharing.
          </p>
          <div style={{marginTop:24,display:"flex",justifyContent:"center",gap:24,color:G.muted,fontSize:11,letterSpacing:".08em",textTransform:"uppercase"}}>
            {["Image","Audio","Video","URL"].map(t=><span key={t} style={{opacity:.35}}>{t}</span>)}
          </div>
        </div>}
      </main>

      <footer style={{padding:"14px 48px",borderTop:`1px solid ${G.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted,letterSpacing:".06em"}}>◐ THE OTHER SIDE · CLARITY THROUGH PERSPECTIVE</span>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:G.muted}}>claude-sonnet-4</span>
      </footer>
    </div>
  </>;
}
