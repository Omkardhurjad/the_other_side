"""
tests/test_agent.py — Unit + integration tests for The Other Side Agent
=======================================================================
Run with:  pytest tests/ -v
"""

import json
import pytest
from unittest.mock import MagicMock, patch

# ── Unit tests: tools ─────────────────────────────────────────────────────────

from the_other_side_agent.agent import (
    describe_perspective,
    build_poem_storyboard,
    validate_poem_json,
    ANGLES,
)


class TestDescribePerspective:
    def test_valid_angle(self):
        result = describe_perspective("A photo of a protest march", angle="empathy")
        assert result["angle_label"] == "Empathy Mirror"
        assert "desc_prompt" in result

    def test_invalid_angle_falls_back(self):
        result = describe_perspective("Some situation", angle="nonexistent")
        assert result["angle_label"] == "Empathy Mirror"  # fallback

    def test_all_angles_supported(self):
        for angle in ANGLES:
            result = describe_perspective("test", angle=angle)
            assert result["angle_label"] == ANGLES[angle]["label"]


class TestBuildPoemStoryboard:
    def test_returns_poem_tone(self):
        result = build_poem_storyboard(
            original_description="A man photographed a struggling bird.",
            angle="empathy",
        )
        assert "poem_tone" in result
        assert "frame_arc" in result
        assert "original_description" in result

    def test_frame_arc_includes_five_labels(self):
        result = build_poem_storyboard("test", angle="conflict")
        arc = result["frame_arc"]
        for i in range(1, 6):
            assert f"Stanza {i}" in arc


class TestValidatePoemJson:
    VALID_JSON = json.dumps({
        "frames": [
            {"sceneLabel": "Scene One", "emoji": "🌊", "lines": ["l1", "l2", "l3", "l4"]},
            {"sceneLabel": "Scene Two", "emoji": "🔥", "lines": ["l1", "l2", "l3", "l4"]},
        ]
    })

    def test_valid_json_passes(self):
        result = validate_poem_json(self.VALID_JSON)
        assert result["valid"] is True
        assert len(result["frames"]) == 2

    def test_strips_markdown_fences(self):
        fenced = f"```json\n{self.VALID_JSON}\n```"
        result = validate_poem_json(fenced)
        assert result["valid"] is True

    def test_empty_frames_fails(self):
        result = validate_poem_json('{"frames": []}')
        assert result["valid"] is False

    def test_missing_keys_fails(self):
        bad = json.dumps({"frames": [{"sceneLabel": "X", "emoji": "✨"}]})
        result = validate_poem_json(bad)
        assert result["valid"] is False

    def test_wrong_line_count_fails(self):
        bad = json.dumps({"frames": [
            {"sceneLabel": "X", "emoji": "✨", "lines": ["only", "three", "lines"]}
        ]})
        result = validate_poem_json(bad)
        assert result["valid"] is False

    def test_invalid_json_returns_error(self):
        result = validate_poem_json("not json at all {")
        assert result["valid"] is False
        assert "error" in result


# ── Integration tests: FastAPI endpoints ──────────────────────────────────────

from fastapi.testclient import TestClient
import sys, os

# Add parent dir to path for import
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


@pytest.fixture
def client():
    """Create test client — mocks ADK internals."""
    with patch("google.adk.cli.fast_api.get_fast_api_app") as mock_app_fn:
        from fastapi import FastAPI
        mock_fastapi = FastAPI()
        mock_app_fn.return_value = mock_fastapi

        from main import app
        return TestClient(app)


class TestHealthEndpoint:
    def test_health_returns_ok(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


class TestAnglesEndpoint:
    def test_returns_all_angles(self, client):
        resp = client.get("/angles")
        assert resp.status_code == 200
        data = resp.json()
        for angle in ["empathy", "conflict", "bias", "history", "devil"]:
            assert angle in data

    def test_each_angle_has_label(self, client):
        resp = client.get("/angles")
        for angle_data in resp.json().values():
            assert "label" in angle_data
            assert "frame_labels" in angle_data
            assert len(angle_data["frame_labels"]) == 5


class TestUploadMediaEndpoint:
    def test_rejects_oversized_file(self, client):
        large_content = b"x" * (11 * 1024 * 1024)  # 11 MB
        resp = client.post(
            "/upload-media",
            files={"file": ("big.jpg", large_content, "image/jpeg")},
            data={"angle": "empathy"},
        )
        assert resp.status_code == 413

    def test_rejects_unsupported_mime(self, client):
        resp = client.post(
            "/upload-media",
            files={"file": ("doc.pdf", b"fake pdf content", "application/pdf")},
            data={"angle": "empathy"},
        )
        assert resp.status_code == 415

    def test_accepts_valid_image(self, client):
        # Minimal 1x1 JPEG
        tiny_jpeg = (
            b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01'
            b'\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07'
            b'\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14'
            b'\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $.\' ",#\x1c\x1c(7),01444'
            b'\x1f\'9=82<.342\x1edL\t\x13\x0eRDQ\x00\xff\xd9'
        )
        resp = client.post(
            "/upload-media",
            files={"file": ("test.jpg", tiny_jpeg, "image/jpeg")},
            data={"angle": "empathy", "context": "test context"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "media_data_uri" in data
        assert data["media_data_uri"].startswith("data:image/jpeg;base64,")
        assert data["angle"] == "empathy"


# ── Guardrail tests ───────────────────────────────────────────────────────────

class TestGuardrails:
    """Ensure the agent's guardrail logic holds at the tool level."""

    def test_angle_fallback_never_crashes(self):
        """Any unknown angle must gracefully fall back to empathy."""
        for bad_angle in ["", "random", "none", "ALL", "💀"]:
            result = describe_perspective("test situation", angle=bad_angle)
            assert result["angle_label"] == ANGLES["empathy"]["label"]

    def test_poem_json_empty_string(self):
        result = validate_poem_json("")
        assert result["valid"] is False

    def test_poem_json_none_like_input(self):
        result = validate_poem_json("null")
        assert result["valid"] is False

    def test_poem_json_wrong_root_key(self):
        result = validate_poem_json('{"stanzas": []}')
        assert result["valid"] is False
